package controller;
import model.*;
import java.util.ArrayList;


public class Sistema {
    public ArrayList<Utente> utenti;
    public Prenotazione biglietto;
    public UtenteGenerico utente;
    public Admin admin;
    public ArrayList<Volo> tuttiIVoli;
    public ArrayList<Prenotazione> tuttiIBiglietti;

    public Sistema(){
        utenti = new ArrayList<>();
        utente = new UtenteGenerico("karol", " leonardi");
        admin = new Admin("saso","saso", "231223");
        tuttiIVoli = new ArrayList<>();
        tuttiIBiglietti = new ArrayList<>();
        biglietto = new Prenotazione(312321123,"a3", Prenotazione.StatoPrenotazione.CONFERMATA, new Passeggero("", "", ""), new Volo(21, "", "15:00",12_21, Volo.statoVolo.PROGRAMMATO, "","","2"));
    }
    public void aggiungiUtente(Utente ug){
        utenti.add(ug);
    }
    public void aggiungiVolo(Volo v){
        admin.aggiungiVoli(v);
    }
    public ArrayList<Volo> visualizzaVoli(){
        return utente.visualizzaVoli();
    }
    //aggiungi il biglietto tra i biglietti acquistati dell'utente e tutti i biglietti
    public void aggiungiBiglietto(Prenotazione biglietto){
        utente.prenotaVolo(biglietto);
        tuttiIBiglietti.add(biglietto);
    }
    //cancella un biglietto
    public boolean cancellaBiglietto(long numeroBiglietto){
        return biglietto.cancellaBiglietto(tuttiIBiglietti,numeroBiglietto, utente.bigliettiAcquistati);
    }
    //crea il numero di un biglietto unico
    public Long creaNumBiglietto(){
        return biglietto.creaNumeroBiglietto(tuttiIBiglietti);
    }
    public ArrayList getBiglietti(String nome, int codiceVolo){
        return utente.cercaBiglietto(nome,codiceVolo);
    }
    public int verificaUtenteP(String username, String psw){
        for(Utente u : utenti){
            if(u.getNomeUtente().equals(username) && u.getPsw().equals(psw)){
                if(u instanceof UtenteGenerico){
                    return 1;
                }else if(u instanceof Admin){
                    return 2;
                }
            }
            System.out.println(u.getNomeUtente()+" "+u.getPsw());
        }

        return 0;
    }
    public void setUtenteLoggato(UtenteGenerico u){
        this.utente = u;
    }

    public void logout(Utente utente){
        utente =null;
    }
}